﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace KakaoMap00
{
    public partial class loading : Form
    {
        delegate void TestDelegate_ShowCnt(string msg);
        delegate void TestDelegate_Close();
        public loading()
        {
            InitializeComponent();
            Thread thread = new Thread(Thread1);
            thread.Start();
        }

        private void formClose()
        {
            this.Close();
        }
        private void Thread1()
        {
            for(int i = 30; i > 0; i --)
            {
                Thread.Sleep(100);
            }
            this.Invoke(new TestDelegate_Close(formClose));
        }
        private void loading_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }
    }
}
