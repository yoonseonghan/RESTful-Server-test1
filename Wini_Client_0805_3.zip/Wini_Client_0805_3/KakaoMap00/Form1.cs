﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Web.Script.Serialization;
using System.Net;
using System.IO;
using System.Net.Http;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using System.Timers;

namespace KakaoMap00
{
    public partial class Form1 : Form
    {

        public static int target_num = 55; // total query url count

        // 5개의 지역에 관한 쿼리 전송
        static string[] targetURL = {
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0001&ResultType=json",  //인천
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0002&ResultType=json",  //평택
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0003&ResultType=json",  //영광
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0004&ResultType=json",  //제주
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0005&ResultType=json",  //부산
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0006&ResultType=json",  //묵호
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0007&ResultType=json",  //목포
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0008&ResultType=json",  //안산
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0901&ResultType=json",  //포항
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0010&ResultType=json",  //서귀포
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0011&ResultType=json",  //후포
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0012&ResultType=json",  //속초
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0013&ResultType=json",  //울릉도
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0014&ResultType=json",  //통영
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0062&ResultType=json",  //마산
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0016&ResultType=json",  //여수
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0017&ResultType=json",  //대산
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0018&ResultType=json",  //군산
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0063&ResultType=json",  //가덕도
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0020&ResultType=json",  //울산
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0021&ResultType=json",  //추자도
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0022&ResultType=json",  //성산포
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0023&ResultType=json",  //모슬포
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0024&ResultType=json",  //장항
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0025&ResultType=json",  //보령
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0026&ResultType=json",  //고흥발포
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0027&ResultType=json",   //완도
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0028&ResultType=json",  //진도
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0029&ResultType=json",  //거제도
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0030&ResultType=json",  //위도
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0031&ResultType=json",   //거문도
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0032&ResultType=json",  //강화대교
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0034&ResultType=json",  //안흥
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0035&ResultType=json",  //흑산도
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0037&ResultType=json",   //어청도
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0038&ResultType=json",  //굴업도
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0039&ResultType=json",  //왕돌초
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0041&ResultType=json",  //복사초
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0042&ResultType=json",   //교본초
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0043&ResultType=json",  //영흥도
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0044&ResultType=json",  //영종대교
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0049&ResultType=json",  //광양
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0050&ResultType=json",  //태안
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0051&ResultType=json",  //서천마량
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0052&ResultType=json",  //인천송도
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0055&ResultType=json",  //순천만
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0056&ResultType=json",  //부산항신항
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0057&ResultType=json",  //동해항
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0058&ResultType=json",  //경인항
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0061&ResultType=json",  //삼천포
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=IE_0060&ResultType=json",  //이어도
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=IE_0061&ResultType=json",  //신안가거초
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=IE_0062&ResultType=json",  //웅진소청초
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0065&ResultType=json",  //덕적도
        "http://www.khoa.go.kr/oceangrid/grid/api/tideObsRecent/search.do?ServiceKey=QeqUCYmMdKiVhvAoBj6lJw==&ObsCode=DT_0066&ResultType=json",  //향화도
        "http://아이피:포트번호/하위 디렉토리" // 해양 사고 DB를 위한 ip와 포트 넘벌들 넣어보자
        };



        // 지역명, 위도, 경도  (ex. "문정동", "37.412412", "124.512512")
        List<Tuple<string, double, double>> tuples = new List<Tuple<string, double, double>>(); // query로 받은 결과 저장
        
        //item1:지명, item2:경도, item3:위도

        public Form1()
        {
            InitializeComponent();
         
        }
       
        private void Form1_Load(object sender, EventArgs e)
        {
            // WebBrowser 컨트롤에 "kakaoMap.html" 을 표시한다. 
            Version ver = webBrowser1.Version;
            string name = webBrowser1.ProductName;
            string str = webBrowser1.ProductVersion;
            string html = "kakaoMap.html";
            string dir = System.IO.Directory.GetCurrentDirectory();
            string path = System.IO.Path.Combine(dir, html);
            webBrowser1.Navigate(path);

            // timer set
            timer1_Tick(sender, e); // event occur when program is started
            Weatherinit.Interval = 60000; //60second term
            Weatherinit.Start(); // timer on
        }


        private void ShowMap(string atitude, string longitude) // 위도, 경도에 해당하는 지역을 지도에 표시
        {

            //var sel = tuples[listBox1.SelectedIndex];
            double x = double.Parse(atitude);
            double y = double.Parse(longitude);

            object[] arr = new object[] { x, y }; // 위도, 경도
            object res = webBrowser1.Document.InvokeScript("panTo", arr); // html 의 panTo 자바스크립트 함수 호출. 
        }
        ///// 기상청 서버로부터 일정시간마다 받아오는 메소드
        private void timer1_Tick(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear(); // Row initialize

            for (int i = 0; i < target_num; i++)
            {
                string result = string.Empty;
                try
                {
                    WebClient client = new WebClient();

                    //특정 요청 헤더값을 추가해준다. 
                    client.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");

                    using (Stream s_data = client.OpenRead(targetURL[i]))
                    {
                        using (StreamReader reader = new StreamReader(s_data))
                        {
                            string s = reader.ReadToEnd();
                            result = s;
                            reader.Close();
                            s_data.Close();
                        }
                    }
                }
                catch
                {
                    //통신 실패시 처리로직
                    Console.WriteLine(e.ToString());
                }

                //string webClientResult = callWebClient(target_num);

                var r = JObject.Parse(result);

                var list_s = r["result"]; // 2개로 분리  

                var meta = list_s["meta"];

                var data = list_s["data"];

                

                string[] row0 = { string.Format("{0}", meta["obs_post_name"]), string.Format("{0}", meta["obs_lat"]), string.Format("{0}", meta["obs_lon"]),
                string.Format("{0} ℃", data["water_temp"]), string.Format("{0} ℃", data["air_temp"]),string.Format("{0} hPa", data["air_press"]),string.Format("{0} deg", data["wind_dir"]),
                string.Format("{0} m/s", data["wind_speed"]),string.Format("{0} cm", data["tide_level"]), string.Format("{0} ", data["record_time"]) };

                dataGridView1.Rows.Add(row0);


            }
        }

        // 데이터 그리드뷰 클릭 시 해당하는 위도 경도로 이동하는 메소드 //추가로 더 구현 해야함+
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string atitude = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            string longitude = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            ShowMap(atitude, longitude);

            //textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
            //textBox4.Text = dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();


        }
    }
}
